module.exports.authController = require('./auth.controller');
module.exports.userController = require('./user.controller');
module.exports.tankController = require('./tank.controller');
module.exports.dispenserController = require('./dispenser.controller');
module.exports.nozelController = require('./nozel.controller');
